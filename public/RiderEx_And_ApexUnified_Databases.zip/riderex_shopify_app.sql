-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2025 at 11:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `riderex_shopify_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('frame-ancestors_', 'O:15:\"App\\Models\\User\":35:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"users\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:15:{s:2:\"id\";i:4;s:4:\"name\";s:30:\"testriderexstore.myshopify.com\";s:5:\"email\";s:35:\"shop@testriderexstore.myshopify.com\";s:17:\"email_verified_at\";N;s:8:\"password\";s:38:\"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\";s:14:\"remember_token\";N;s:10:\"created_at\";s:19:\"2025-01-07 21:39:12\";s:10:\"updated_at\";s:19:\"2025-01-07 21:39:45\";s:21:\"shopify_grandfathered\";i:0;s:17:\"shopify_namespace\";N;s:16:\"shopify_freemium\";i:0;s:7:\"plan_id\";N;s:10:\"deleted_at\";N;s:19:\"password_updated_at\";s:10:\"2025-01-07\";s:19:\"theme_support_level\";i:2;}s:11:\"\0*\0original\";a:15:{s:2:\"id\";i:4;s:4:\"name\";s:30:\"testriderexstore.myshopify.com\";s:5:\"email\";s:35:\"shop@testriderexstore.myshopify.com\";s:17:\"email_verified_at\";N;s:8:\"password\";s:38:\"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\";s:14:\"remember_token\";N;s:10:\"created_at\";s:19:\"2025-01-07 21:39:12\";s:10:\"updated_at\";s:19:\"2025-01-07 21:39:45\";s:21:\"shopify_grandfathered\";i:0;s:17:\"shopify_namespace\";N;s:16:\"shopify_freemium\";i:0;s:7:\"plan_id\";N;s:10:\"deleted_at\";N;s:19:\"password_updated_at\";s:10:\"2025-01-07\";s:19:\"theme_support_level\";i:2;}s:10:\"\0*\0changes\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:17:\"email_verified_at\";s:8:\"datetime\";s:10:\"deleted_at\";s:8:\"datetime\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:2:{i:0;s:8:\"password\";i:1;s:14:\"remember_token\";}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"email\";i:2;s:8:\"password\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}s:19:\"\0*\0authPasswordName\";s:8:\"password\";s:20:\"\0*\0rememberTokenName\";s:14:\"remember_token\";s:9:\"apiHelper\";N;s:17:\"\0*\0sessionContext\";N;s:16:\"\0*\0forceDeleting\";b:0;}', 1736363769),
('frame-ancestors_testriderexstore.myshopify.com', 'O:15:\"App\\Models\\User\":35:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"users\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:15:{s:2:\"id\";i:4;s:4:\"name\";s:30:\"testriderexstore.myshopify.com\";s:5:\"email\";s:35:\"shop@testriderexstore.myshopify.com\";s:17:\"email_verified_at\";N;s:8:\"password\";s:38:\"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\";s:14:\"remember_token\";N;s:10:\"created_at\";s:19:\"2025-01-07 21:39:12\";s:10:\"updated_at\";s:19:\"2025-01-07 21:39:45\";s:21:\"shopify_grandfathered\";i:0;s:17:\"shopify_namespace\";N;s:16:\"shopify_freemium\";i:0;s:7:\"plan_id\";N;s:10:\"deleted_at\";N;s:19:\"password_updated_at\";s:10:\"2025-01-07\";s:19:\"theme_support_level\";i:2;}s:11:\"\0*\0original\";a:15:{s:2:\"id\";i:4;s:4:\"name\";s:30:\"testriderexstore.myshopify.com\";s:5:\"email\";s:35:\"shop@testriderexstore.myshopify.com\";s:17:\"email_verified_at\";N;s:8:\"password\";s:38:\"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\";s:14:\"remember_token\";N;s:10:\"created_at\";s:19:\"2025-01-07 21:39:12\";s:10:\"updated_at\";s:19:\"2025-01-07 21:39:45\";s:21:\"shopify_grandfathered\";i:0;s:17:\"shopify_namespace\";N;s:16:\"shopify_freemium\";i:0;s:7:\"plan_id\";N;s:10:\"deleted_at\";N;s:19:\"password_updated_at\";s:10:\"2025-01-07\";s:19:\"theme_support_level\";i:2;}s:10:\"\0*\0changes\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:17:\"email_verified_at\";s:8:\"datetime\";s:10:\"deleted_at\";s:8:\"datetime\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:2:{i:0;s:8:\"password\";i:1;s:14:\"remember_token\";}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"email\";i:2;s:8:\"password\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}s:19:\"\0*\0authPasswordName\";s:8:\"password\";s:20:\"\0*\0rememberTokenName\";s:14:\"remember_token\";s:9:\"apiHelper\";N;s:17:\"\0*\0sessionContext\";N;s:16:\"\0*\0forceDeleting\";b:0;}', 1736363843);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `charges`
--

CREATE TABLE `charges` (
  `id` int(10) UNSIGNED NOT NULL,
  `charge_id` bigint(20) NOT NULL,
  `test` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `terms` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `interval` varchar(255) DEFAULT NULL,
  `capped_amount` decimal(8,2) DEFAULT NULL,
  `trial_days` int(11) DEFAULT NULL,
  `billing_on` timestamp NULL DEFAULT NULL,
  `activated_on` timestamp NULL DEFAULT NULL,
  `trial_ends_on` timestamp NULL DEFAULT NULL,
  `cancelled_on` timestamp NULL DEFAULT NULL,
  `expires_on` timestamp NULL DEFAULT NULL,
  `plan_id` int(10) UNSIGNED DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `reference_charge` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2020_01_29_010501_create_plans_table', 1),
(5, '2020_01_29_230905_create_shops_table', 1),
(6, '2020_01_29_231006_create_charges_table', 1),
(7, '2020_07_03_211514_add_interval_column_to_charges_table', 1),
(8, '2020_07_03_211854_add_interval_column_to_plans_table', 1),
(9, '2021_04_21_103633_add_password_updated_at_to_users_table', 1),
(10, '2022_06_09_104819_add_theme_support_level_to_users_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `interval` varchar(255) DEFAULT NULL,
  `capped_amount` decimal(8,2) DEFAULT NULL,
  `terms` varchar(255) DEFAULT NULL,
  `trial_days` int(11) DEFAULT NULL,
  `test` tinyint(1) NOT NULL DEFAULT 0,
  `on_install` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('4lUmbDRwuPG4LnKJb0oQPN9rnz1twYFl8yk3qwo4', 4, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiejBSckVaZktqTTRmWmhWd3V0Nk11TWxERUczNVZpTk1OUVVIdjlkbyI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo3NDY6Imh0dHA6Ly9kNzU5LTEzNy01OS0yMTctMTQyLm5ncm9rLWZyZWUuYXBwLz9ob3N0PVlXUnRhVzR1YzJodmNHbG1lUzVqYjIwdmMzUnZjbVV2ZEdWemRISnBaR1Z5WlhoemRHOXlaUSZsb2NhbGU9ZW4mc2hvcD10ZXN0cmlkZXJleHN0b3JlLm15c2hvcGlmeS5jb20mdG9rZW49ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRYQzloWkcxcGJpSXNJbVJsYzNRaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0SWl3aVlYVmtJam9pTmpObE1XSXlaamswTWpjMVl6SXlNbVEwWXpNd09ETXdOR1EwTlRCbVl6SWlMQ0p6ZFdJaU9pSTVNVFkzT0RZd05UTTJPU0lzSW1WNGNDSTZNVGN6TmpNMU9EVTVNU3dpYm1KbUlqb3hOek0yTXpVNE5UTXhMQ0pwWVhRaU9qRTNNell6TlRnMU16RXNJbXAwYVNJNklqUmlOalkxWlRKbUxXVmxaREF0TkRKbE9TMDRNV1JqTFdSak5UazFZekl3WXpSbU5pSXNJbk5wWkNJNklqazJOakkxWldVeExXUTNZak10TkRBd05TMWhaRFE0TFdNM09XTTBaalpoTVRjd1lpSXNJbk5wWnlJNklqa3pNRGcyWldGbVptRmtOMkkwWVRobE1EVTRPVE15TkdOa09HUTNPV014WkRoaU1UWXhOV1pqTlRRNFpUZzROVFEyWlRKalpHSXdZalV4TXpjMFpUZ2lmUS5oWWw5ZjE2ME53dWJEOTR5bFQzSDA2OWMyMTBNaW1pN2lmay1la2lfRU4wIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1736358580),
('4NMtAR37KBYvN8YSRBxb34UfQRqMF9dWNd9wlS0q', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNWtrM2lVdzV0VDN2c1JaOEc5NkVxWWFBV2N3Y0NXQnFyN3UyS2RrYiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTAxNzoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvYXV0aGVudGljYXRlL3Rva2VuP2VtYmVkZGVkPTEmaG1hYz05NjA5ZDI3NmY0YTNjYWRiY2VhMDk2NGYwOTlhNGQ1OWY1ODQ2ZjQ3OTVmMTRhNTAxNTk4YzlhNDlhMzU3Y2Q2Jmhvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmlkX3Rva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPRFUyT1N3aWJtSm1Jam94TnpNMk16VTROVEE1TENKcFlYUWlPakUzTXpZek5UZzFNRGtzSW1wMGFTSTZJamhpT1RVM056a3dMV05pWXpVdE5EZGhZUzFpTWprMkxUUTVZamMxTW1NME5qVTFZeUlzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJak0zTVRkbVlUVXdNMlU1WVRoa01HVmpOR1U0WVRWak1qWXpNak0wTmpNek56aGlORFExTm1FNE1qRm1NV00xWVRnd01qUXlNMk16TldRMk5UUXpNRGdpZlEuR2stQmVFODJEdktSdVU2dDA0S012cGg3Zy02N0FONzhJazRYUVRqd21URSZsb2NhbGU9ZW4mc2Vzc2lvbj04OTk4NGMyMzRiNTMzMjVlZmYyZTBkMjUzYTNlMGU3ZTdlMTMwMWNkYzUxMmNlZTQ1NmUzZmFiZjExYjJiMWZjJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRhcmdldD0lMkYlM0Zob3N0JTNEWVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJnRpbWVzdGFtcD0xNzM2MzU4NTA5Ijt9fQ==', 1736358552),
('5zdtqOE7Q3ST2stUJoeVBPrUd19LI1RW6dnkp2yj', 4, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiOExtZFRjZEt3ZDJ6MXpPM3Y1UldOOXY3dWVZdWlVaEVBWnUwSm95ZiI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoxMzU4OiJodHRwOi8vZDc1OS0xMzctNTktMjE3LTE0Mi5uZ3Jvay1mcmVlLmFwcC8/ZW1iZWRkZWQ9MSZob3N0PVlXUnRhVzR1YzJodmNHbG1lUzVqYjIwdmMzUnZjbVV2ZEdWemRISnBaR1Z5WlhoemRHOXlaUSZpZF90b2tlbj1leUpoYkdjaU9pSklVekkxTmlJc0luUjVjQ0k2SWtwWFZDSjkuZXlKcGMzTWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dFhDOWhaRzFwYmlJc0ltUmxjM1FpT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRJaXdpWVhWa0lqb2lOak5sTVdJeVpqazBNamMxWXpJeU1tUTBZek13T0RNd05HUTBOVEJtWXpJaUxDSnpkV0lpT2lJNU1UWTNPRFl3TlRNMk9TSXNJbVY0Y0NJNk1UY3pOak0xT0RjMk1pd2libUptSWpveE56TTJNelU0TnpBeUxDSnBZWFFpT2pFM016WXpOVGczTURJc0ltcDBhU0k2SW1JNFpqRXhaVE5pTFdObFlqQXROR05qTXkxaFpUSmlMV1kxWW1Fd1pqZzFaakJtWlNJc0luTnBaQ0k2SWprMk5qSTFaV1V4TFdRM1lqTXROREF3TlMxaFpEUTRMV00zT1dNMFpqWmhNVGN3WWlJc0luTnBaeUk2SWpWbU5UazNNamMzTkRJME1UZGpaR0k0TTJKak5tUmtOMlpqTVdFd01qSmpaVGt4T0RBMU9UWmhOMkZpTURkallqYzNZMlprWlRSbVkyUmlZemhqTTJVaWZRLlM2XzFac1cyUDBzVEFLM01MLXZRRk1UZzE4VDdZdVg4bUl2bENFZU9sVGsmbG9jYWxlPWVuJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPRGMyT1N3aWJtSm1Jam94TnpNMk16VTROekE1TENKcFlYUWlPakUzTXpZek5UZzNNRGtzSW1wMGFTSTZJamxoWXpoallUTXpMVFJsWWpRdE5HSTJZaTA1WVdVMExUZ3dNRFptTnpSbFlqbGpNaUlzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJbU14WVRGaE16RmpORFJqWmpBMU16WTJNRFEzTURWak56QmlNbUUyT1dWaE1qQTBPV1ZpWmpReE4yVTFaVEppTURFeU5ETXdZMkU1Wm1RM1pqVmpNVEVpZlEuN1NXeVVQTkl2TEdVa01iZlZpOHBmMEpCeGp6eEZwa0ZLdzNjTDdmbDJmbyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736358779),
('9c8duuaxTHwIexxNNaw5hpd3wRlAU2aLYFkZjb2b', 4, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiODdHQW5yVnB6dEcxa1FUV2NWeURoNG5kNnVaaHNIMUpmMmd6MmVONyI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoxNTIyOiJodHRwOi8vZDc1OS0xMzctNTktMjE3LTE0Mi5uZ3Jvay1mcmVlLmFwcC8/ZW1iZWRkZWQ9MSZobWFjPWMyYjBiM2JmMTNiNzhmOWNhMmIzMjBkMWY4ZGU0MTU4ZTJjZTQ3MmZhMGM5OGI3YmVkMmEzNWQyMTEzMTA5MTYmaG9zdD1ZV1J0YVc0dWMyaHZjR2xtZVM1amIyMHZjM1J2Y21VdmRHVnpkSEpwWkdWeVpYaHpkRzl5WlEmaWRfdG9rZW49ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRYQzloWkcxcGJpSXNJbVJsYzNRaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0SWl3aVlYVmtJam9pTmpObE1XSXlaamswTWpjMVl6SXlNbVEwWXpNd09ETXdOR1EwTlRCbVl6SWlMQ0p6ZFdJaU9pSTVNVFkzT0RZd05UTTJPU0lzSW1WNGNDSTZNVGN6TmpNMU9URXpNQ3dpYm1KbUlqb3hOek0yTXpVNU1EY3dMQ0pwWVhRaU9qRTNNell6TlRrd056QXNJbXAwYVNJNkltVTVabUk0Tm1NeUxUQmxNV0V0TkRNNU5pMWhOVFl5TFdSbVl6WXpPV1F6WlRReU1DSXNJbk5wWkNJNklqazJOakkxWldVeExXUTNZak10TkRBd05TMWhaRFE0TFdNM09XTTBaalpoTVRjd1lpSXNJbk5wWnlJNkltTmxNelkyWXpZeU56TTFPRGxtWVdSak56QXlOelJtWVRZMFpXUmtPVGMwWldKaU5XUXlOekV3TWpJMFpUZ3lPRFEyT0RGa01XUTFZamRpTXpJM1pqVWlmUS5Ra0RxY19xZVdIUXZxTEMxM0VZaVRPUlBOeUJ0Z2g4ZThpS0RTUV9Ob0d3JmxvY2FsZT1lbiZzZXNzaW9uPTg5OTg0YzIzNGI1MzMyNWVmZjJlMGQyNTNhM2UwZTdlN2UxMzAxY2RjNTEyY2VlNDU2ZTNmYWJmMTFiMmIxZmMmc2hvcD10ZXN0cmlkZXJleHN0b3JlLm15c2hvcGlmeS5jb20mdGltZXN0YW1wPTE3MzYzNTkwNzAmdG9rZW49ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRYQzloWkcxcGJpSXNJbVJsYzNRaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0SWl3aVlYVmtJam9pTmpObE1XSXlaamswTWpjMVl6SXlNbVEwWXpNd09ETXdOR1EwTlRCbVl6SWlMQ0p6ZFdJaU9pSTVNVFkzT0RZd05UTTJPU0lzSW1WNGNDSTZNVGN6TmpNMU9UQTVNU3dpYm1KbUlqb3hOek0yTXpVNU1ETXhMQ0pwWVhRaU9qRTNNell6TlRrd016RXNJbXAwYVNJNkltRmhOek0yWXpkakxXWXpZVGN0TkROak5TMWhOVFk1TFRRNFlUbGpNakE0T1dFMlpDSXNJbk5wWkNJNklqazJOakkxWldVeExXUTNZak10TkRBd05TMWhaRFE0TFdNM09XTTBaalpoTVRjd1lpSXNJbk5wWnlJNklqZzRNbUV3WWpobFlUazBPR0UyTURjMU56Y3hPVFF3TldJellUQmpZMll5WldFd1ptSmxNemsxWkdNME5EazFOVEJoT0RJeE9UUmhaREU0TW1Vd05XRWlmUS56MkJLbmFRTGZFMmlpSG03TDk1enlZLWdYSExmTEpGNENlZXdONTNzajM4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1736359101),
('AgRfi8QnAWZhIVfV960M05p8g2K7CBIm9pA6v3Ov', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibU4zd0ttZlE2S3ZoWDZKSU80akdRUHhxRFlmcjF0TG5qWmE1R3dQeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTUyMjoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvP2VtYmVkZGVkPTEmaG1hYz01MzkwOGQwNDVjNWY3YjhhMjc1NmU3ZDNlNTZiMTg0YWFlNDdjMWNmMmFiMmNiYTExMzEzMzc1ZDNjNTIzZGRjJmhvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmlkX3Rva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPRGMyTWl3aWJtSm1Jam94TnpNMk16VTROekF5TENKcFlYUWlPakUzTXpZek5UZzNNRElzSW1wMGFTSTZJbUk0WmpFeFpUTmlMV05sWWpBdE5HTmpNeTFoWlRKaUxXWTFZbUV3WmpnMVpqQm1aU0lzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJalZtTlRrM01qYzNOREkwTVRkalpHSTRNMkpqTm1Sa04yWmpNV0V3TWpKalpUa3hPREExT1RaaE4yRmlNRGRqWWpjM1kyWmtaVFJtWTJSaVl6aGpNMlVpZlEuUzZfMVpzVzJQMHNUQUszTUwtdlFGTVRnMThUN1l1WDhtSXZsQ0VlT2xUayZsb2NhbGU9ZW4mc2Vzc2lvbj04OTk4NGMyMzRiNTMzMjVlZmYyZTBkMjUzYTNlMGU3ZTdlMTMwMWNkYzUxMmNlZTQ1NmUzZmFiZjExYjJiMWZjJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRpbWVzdGFtcD0xNzM2MzU4NzAyJnRva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPRFU1TVN3aWJtSm1Jam94TnpNMk16VTROVE14TENKcFlYUWlPakUzTXpZek5UZzFNekVzSW1wMGFTSTZJalJpTmpZMVpUSm1MV1ZsWkRBdE5ESmxPUzA0TVdSakxXUmpOVGsxWXpJd1l6Um1OaUlzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJamt6TURnMlpXRm1abUZrTjJJMFlUaGxNRFU0T1RNeU5HTmtPR1EzT1dNeFpEaGlNVFl4Tldaak5UUTRaVGc0TlRRMlpUSmpaR0l3WWpVeE16YzBaVGdpZlEuaFlsOWYxNjBOd3ViRDk0eWxUM0gwNjljMjEwTWltaTdpZmstZWtpX0VOMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736358733),
('Ao4njVaQsYRm2qlJ74QjZvtQktbq7B0Kjz8kkZbA', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidWZocXhxYlRMbTBxWFZ3eTNtYXdLMWNNanlLM2xPWTljUkNSQUZFWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTUyMjoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvP2VtYmVkZGVkPTEmaG1hYz0yOWZjYmQ1MjFmYzU1NjUyMzYzNGQ5NTIzOTlhYzlmMjA2YTQ1YWU3OWM0MzM3MDFjNDUyZWU3MTM0NzJhMzExJmhvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmlkX3Rva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPRGszT0N3aWJtSm1Jam94TnpNMk16VTRPVEU0TENKcFlYUWlPakUzTXpZek5UZzVNVGdzSW1wMGFTSTZJak0zTkdFNVltUTJMVEJrT0RZdE5EbGhOUzFoWWpNNUxXTXhNMk5rTUdJMU1ETmxPU0lzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJbVU0TmpGbU1HVXdPVFkwWkdaaE1qWTBPVEl4WkROaE9UUTNObVUxWkRWalpXSmtNRFV3WmpGall6a3lNbVEyTVdJd1pESmtZVEpqWW1Rd09ESmtNRGtpZlEuX205TTM5MU5mWW1fMjUwYmhVVUdEYjA5bmsyajZKZ3dtdi05ZWlNNnJBbyZsb2NhbGU9ZW4mc2Vzc2lvbj04OTk4NGMyMzRiNTMzMjVlZmYyZTBkMjUzYTNlMGU3ZTdlMTMwMWNkYzUxMmNlZTQ1NmUzZmFiZjExYjJiMWZjJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRpbWVzdGFtcD0xNzM2MzU4OTE4JnRva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPRGMyT1N3aWJtSm1Jam94TnpNMk16VTROekE1TENKcFlYUWlPakUzTXpZek5UZzNNRGtzSW1wMGFTSTZJamxoWXpoallUTXpMVFJsWWpRdE5HSTJZaTA1WVdVMExUZ3dNRFptTnpSbFlqbGpNaUlzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJbU14WVRGaE16RmpORFJqWmpBMU16WTJNRFEzTURWak56QmlNbUUyT1dWaE1qQTBPV1ZpWmpReE4yVTFaVEppTURFeU5ETXdZMkU1Wm1RM1pqVmpNVEVpZlEuN1NXeVVQTkl2TEdVa01iZlZpOHBmMEpCeGp6eEZwa0ZLdzNjTDdmbDJmbyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736358960),
('BGTTY1BCxa5BXjv1AOcrnF3ifmgwpuzOQ9Tzkuo4', 4, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRjJ6djdXcUVtQ2F3TjNRY3M3Y2RieHMzb2lFSHZFZ25VSHNQd25PUyI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoxMzU4OiJodHRwOi8vZDc1OS0xMzctNTktMjE3LTE0Mi5uZ3Jvay1mcmVlLmFwcC8/ZW1iZWRkZWQ9MSZob3N0PVlXUnRhVzR1YzJodmNHbG1lUzVqYjIwdmMzUnZjbVV2ZEdWemRISnBaR1Z5WlhoemRHOXlaUSZpZF90b2tlbj1leUpoYkdjaU9pSklVekkxTmlJc0luUjVjQ0k2SWtwWFZDSjkuZXlKcGMzTWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dFhDOWhaRzFwYmlJc0ltUmxjM1FpT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRJaXdpWVhWa0lqb2lOak5sTVdJeVpqazBNamMxWXpJeU1tUTBZek13T0RNd05HUTBOVEJtWXpJaUxDSnpkV0lpT2lJNU1UWTNPRFl3TlRNMk9TSXNJbVY0Y0NJNk1UY3pOak0xT0RrM09Dd2libUptSWpveE56TTJNelU0T1RFNExDSnBZWFFpT2pFM016WXpOVGc1TVRnc0ltcDBhU0k2SWpNM05HRTVZbVEyTFRCa09EWXRORGxoTlMxaFlqTTVMV014TTJOa01HSTFNRE5sT1NJc0luTnBaQ0k2SWprMk5qSTFaV1V4TFdRM1lqTXROREF3TlMxaFpEUTRMV00zT1dNMFpqWmhNVGN3WWlJc0luTnBaeUk2SW1VNE5qRm1NR1V3T1RZMFpHWmhNalkwT1RJeFpETmhPVFEzTm1VMVpEVmpaV0prTURVd1pqRmpZemt5TW1RMk1XSXdaREprWVRKalltUXdPREprTURraWZRLl9tOU0zOTFOZlltXzI1MGJoVVVHRGIwOW5rMmo2Smd3bXYtOWVpTTZyQW8mbG9jYWxlPWVuJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPVEE1TVN3aWJtSm1Jam94TnpNMk16VTVNRE14TENKcFlYUWlPakUzTXpZek5Ua3dNekVzSW1wMGFTSTZJbUZoTnpNMll6ZGpMV1l6WVRjdE5ETmpOUzFoTlRZNUxUUTRZVGxqTWpBNE9XRTJaQ0lzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJamc0TW1Fd1lqaGxZVGswT0dFMk1EYzFOemN4T1RRd05XSXpZVEJqWTJZeVpXRXdabUpsTXprMVpHTTBORGsxTlRCaE9ESXhPVFJoWkRFNE1tVXdOV0VpZlEuejJCS25hUUxmRTJpaUhtN0w5NXp5WS1nWEhMZkxKRjRDZWV3TjUzc2ozOCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736359056),
('dD3QuPtL7TPdxFxnG1JTf168HLxiVBtAs2NxDPVT', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVHVXTDI0bWdnQXhBN0FUQ1NqUnF5NGZhOEFzWHdXVWVLOXVQT0RPUCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTQ2MzoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvYXV0aGVudGljYXRlL3Rva2VuP2hvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmxvY2FsZT1lbiZzaG9wPXRlc3RyaWRlcmV4c3RvcmUubXlzaG9waWZ5LmNvbSZ0YXJnZXQ9JTJGJTNGZW1iZWRkZWQlM0QxJTI2aG9zdCUzRFlXUnRhVzR1YzJodmNHbG1lUzVqYjIwdmMzUnZjbVV2ZEdWemRISnBaR1Z5WlhoemRHOXlaUSUyNmlkX3Rva2VuJTNEZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRYQzloWkcxcGJpSXNJbVJsYzNRaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0SWl3aVlYVmtJam9pTmpObE1XSXlaamswTWpjMVl6SXlNbVEwWXpNd09ETXdOR1EwTlRCbVl6SWlMQ0p6ZFdJaU9pSTVNVFkzT0RZd05UTTJPU0lzSW1WNGNDSTZNVGN6TmpNMU9EazNPQ3dpYm1KbUlqb3hOek0yTXpVNE9URTRMQ0pwWVhRaU9qRTNNell6TlRnNU1UZ3NJbXAwYVNJNklqTTNOR0U1WW1RMkxUQmtPRFl0TkRsaE5TMWhZak01TFdNeE0yTmtNR0kxTURObE9TSXNJbk5wWkNJNklqazJOakkxWldVeExXUTNZak10TkRBd05TMWhaRFE0TFdNM09XTTBaalpoTVRjd1lpSXNJbk5wWnlJNkltVTROakZtTUdVd09UWTBaR1poTWpZME9USXhaRE5oT1RRM05tVTFaRFZqWldKa01EVXdaakZqWXpreU1tUTJNV0l3WkRKa1lUSmpZbVF3T0RKa01Ea2lmUS5fbTlNMzkxTmZZbV8yNTBiaFVVR0RiMDluazJqNkpnd212LTllaU02ckFvJTI2dG9rZW4lM0RleUpoYkdjaU9pSklVekkxTmlJc0luUjVjQ0k2SWtwWFZDSjkuZXlKcGMzTWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dFhDOWhaRzFwYmlJc0ltUmxjM1FpT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRJaXdpWVhWa0lqb2lOak5sTVdJeVpqazBNamMxWXpJeU1tUTBZek13T0RNd05HUTBOVEJtWXpJaUxDSnpkV0lpT2lJNU1UWTNPRFl3TlRNMk9TSXNJbVY0Y0NJNk1UY3pOak0xT0RjMk9Td2libUptSWpveE56TTJNelU0TnpBNUxDSnBZWFFpT2pFM016WXpOVGczTURrc0ltcDBhU0k2SWpsaFl6aGpZVE16TFRSbFlqUXROR0kyWWkwNVlXVTBMVGd3TURabU56UmxZamxqTWlJc0luTnBaQ0k2SWprMk5qSTFaV1V4TFdRM1lqTXROREF3TlMxaFpEUTRMV00zT1dNMFpqWmhNVGN3WWlJc0luTnBaeUk2SW1NeFlURmhNekZqTkRSalpqQTFNelkyTURRM01EVmpOekJpTW1FMk9XVmhNakEwT1dWaVpqUXhOMlUxWlRKaU1ERXlORE13WTJFNVptUTNaalZqTVRFaWZRLjdTV3lVUE5JdkxHVWtNYmZWaThwZjBKQnhqenhGcGtGS3czY0w3ZmwyZm8iO319', 1736358961),
('DoGenThnlBez2q3H4jHykUCkINWM6DEbcgsu5lRQ', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoiSHJ1b1pEa09lTkFpRWZFZ29OUUx3dzJTOFdiZ0tFNE1ZUzFla1dqWSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1736357459),
('eqh7NQ8V9SMSFuNnlJzfZ8l2zWbZ6urfJykozS3b', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVkRnTkFWRXE4R2RmRkhUZXZXTFI3TmhoOHhEMFdzV0VvZ0dYeWRodSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTUyMjoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvP2VtYmVkZGVkPTEmaG1hYz05ZTVlMjk4ZThjZTU1MTQ4MTg1ZGU5MzI3ZjMwOTc0ZWNhZWRiOThjOWJlNzQ3NGFmYmY0MDVkOTJjZDNjOGZlJmhvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmlkX3Rva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPRGMwT0N3aWJtSm1Jam94TnpNMk16VTROamc0TENKcFlYUWlPakUzTXpZek5UZzJPRGdzSW1wMGFTSTZJbVEwWm1JNVpqQXlMV1kxTWpBdE5ERTFOUzA0TnpRNExUSmtOR1k0TVRVMlptVmtNU0lzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJamczT1RJMlpXTXhOR0k1TXpRMVkyWTFPV1JoTVdKaFlqVTVPRFUyTUdWaU1ESmlOR05pWXpabU5HVXhNVGs1T1dObE1EUTNNbVF5Tm1KbVlUWTVNVFFpZlEuWVhNUVZkZUZBeU03VnY1NlJlRXdlSGtLaVZWNDY2WWZORnYwdkIybE5CVSZsb2NhbGU9ZW4mc2Vzc2lvbj04OTk4NGMyMzRiNTMzMjVlZmYyZTBkMjUzYTNlMGU3ZTdlMTMwMWNkYzUxMmNlZTQ1NmUzZmFiZjExYjJiMWZjJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRpbWVzdGFtcD0xNzM2MzU4Njg4JnRva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFPRFU1TVN3aWJtSm1Jam94TnpNMk16VTROVE14TENKcFlYUWlPakUzTXpZek5UZzFNekVzSW1wMGFTSTZJalJpTmpZMVpUSm1MV1ZsWkRBdE5ESmxPUzA0TVdSakxXUmpOVGsxWXpJd1l6Um1OaUlzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJamt6TURnMlpXRm1abUZrTjJJMFlUaGxNRFU0T1RNeU5HTmtPR1EzT1dNeFpEaGlNVFl4Tldaak5UUTRaVGc0TlRRMlpUSmpaR0l3WWpVeE16YzBaVGdpZlEuaFlsOWYxNjBOd3ViRDk0eWxUM0gwNjljMjEwTWltaTdpZmstZWtpX0VOMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736358723),
('eQTGx1H90y8hAkexgs8j5Toc3EKFZZAf3gH6JPX1', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoialJLU05YZ0NpMWo4V1J5RzdkeTVqaGgzWTczdUFJSTgxY0M5ekwyZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjMxOiJodHRwOi8vZDc1OS0xMzctNTktMjE3LTE0Mi5uZ3Jvay1mcmVlLmFwcC9hdXRoZW50aWNhdGUvdG9rZW4/aG9zdD1ZV1J0YVc0dWMyaHZjR2xtZVM1amIyMHZjM1J2Y21VdmRHVnpkSEpwWkdWeVpYaHpkRzl5WlEmc2hvcD10ZXN0cmlkZXJleHN0b3JlLm15c2hvcGlmeS5jb20mdGFyZ2V0PSUyRiUzRmhvc3QlM0RZV1J0YVc0dWMyaHZjR2xtZVM1amIyMHZjM1J2Y21VdmRHVnpkSEpwWkdWeVpYaHpkRzl5WlEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1736358528),
('n7ZRMXA78oUPmzKTBMF311aihR98AwLRqCm78AoU', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoicVZPTlJmRGtYYUdJOEhtbEVOUTZlenNwTzVQUTZxdDZsRDZ0VmpZaiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1736357641),
('Omk1Qe1Ju1iFVM7tbOXtldtJmW63LVZ3FExgJie0', 4, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoib1B0bkFHclV5b2dnZTVCeWM3VWVDWjZMUkp1SWFEeGJSVVFIc01aSyI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo3NDY6Imh0dHA6Ly9kNzU5LTEzNy01OS0yMTctMTQyLm5ncm9rLWZyZWUuYXBwLz9ob3N0PVlXUnRhVzR1YzJodmNHbG1lUzVqYjIwdmMzUnZjbVV2ZEdWemRISnBaR1Z5WlhoemRHOXlaUSZsb2NhbGU9ZW4mc2hvcD10ZXN0cmlkZXJleHN0b3JlLm15c2hvcGlmeS5jb20mdG9rZW49ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRYQzloWkcxcGJpSXNJbVJsYzNRaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0SWl3aVlYVmtJam9pTmpObE1XSXlaamswTWpjMVl6SXlNbVEwWXpNd09ETXdOR1EwTlRCbVl6SWlMQ0p6ZFdJaU9pSTVNVFkzT0RZd05UTTJPU0lzSW1WNGNDSTZNVGN6TmpNMU56UXpPU3dpYm1KbUlqb3hOek0yTXpVM016YzVMQ0pwWVhRaU9qRTNNell6TlRjek56a3NJbXAwYVNJNkltWXpZMkkwTWpVekxXUXdZV1V0TkRKaU9TMWlORE14TFdJM05qSTJNVGxqTXpCak5DSXNJbk5wWkNJNklqazJOakkxWldVeExXUTNZak10TkRBd05TMWhaRFE0TFdNM09XTTBaalpoTVRjd1lpSXNJbk5wWnlJNkltRm1aV015TkRRMU5HSTRObUZrTmprMFlqZ3lOREExWW1GaVlUWTJORFJsWlRJMVlqVmlORGMzTURKak5qbGhaV1prTXpobU1tWTFOV1poWm1KbFpXVWlmUS56amlYVzlQMGNCSzJHUWo5ODB4UFVnbDNnNldGZkVRZkNjd0ZETTFPSlZ3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1736357421),
('QMGz0CwAKxlKLJUvcuQlWlWLgn7z8HJMITWdTXyU', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQnJqU21PcnBPNFFXVVA1Rmg3MEVKRVp6TTFGa1d4azVSOTVLSUVINCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTUyMjoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvP2VtYmVkZGVkPTEmaG1hYz0zMDUzMTYzZmE4ZDNiNjc0MmIwZmVlNGM2MGFkNzg0YTZhMzhjMmEzMjQyN2MzNTk5OGIyZjdlNzI4NGNmYjVmJmhvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmlkX3Rva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFOelUzTml3aWJtSm1Jam94TnpNMk16VTNOVEUyTENKcFlYUWlPakUzTXpZek5UYzFNVFlzSW1wMGFTSTZJbVZpWTJNNE1qTmlMVFprT1RrdE5EbGpOaTFpTjJJekxUYzJZbVExWm1WaE9EUTVOQ0lzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJalZsTkRCbE9UWXhOakZrTmpNek1URXdNV1k0TVROak9ESXhZekZpTldVMVltTXpabVV4WVdGa05UTmlNVGxsTXpNek5EZGlZakExTkdFMFl6VXdNRFlpZlEubVdyVVE4ZUdfa3lLNjFBMFpsSlVPQWt5dnFPOUkzY2dRblNfS3Z2d2NZWSZsb2NhbGU9ZW4mc2Vzc2lvbj04OTk4NGMyMzRiNTMzMjVlZmYyZTBkMjUzYTNlMGU3ZTdlMTMwMWNkYzUxMmNlZTQ1NmUzZmFiZjExYjJiMWZjJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRpbWVzdGFtcD0xNzM2MzU3NTE2JnRva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFOelF6T1N3aWJtSm1Jam94TnpNMk16VTNNemM1TENKcFlYUWlPakUzTXpZek5UY3pOemtzSW1wMGFTSTZJbVl6WTJJME1qVXpMV1F3WVdVdE5ESmlPUzFpTkRNeExXSTNOakkyTVRsak16QmpOQ0lzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJbUZtWldNeU5EUTFOR0k0Tm1Ga05qazBZamd5TkRBMVltRmlZVFkyTkRSbFpUSTFZalZpTkRjM01ESmpOamxoWldaa016aG1NbVkxTldaaFptSmxaV1VpZlEuemppWFc5UDBjQksyR1FqOTgweFBVZ2wzZzZXRmZFUWZDY3dGRE0xT0pWdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736357546),
('ssVZrTiWAJMAgh4GoRWCIewPmhWThLhL3Azxfwwh', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoieVdVeFduZzdlY2hSVFJWdm9pWUdPMVhHQlNrTkJKUmFFM3RBYVRZeSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1736358600),
('TOKSla4CCFWn0SvmqyC01iZgEChpazQB4NEXKAeS', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoiZkdsOUNnS3RRNE5YbkF4ZXFVbGhzc2RsY3dvbldLVDlhcXRzb1l0aSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1736359154),
('xMnKgWI6zJ0DCZJpOue7W96NDKkU0nEl8pGaZkMm', 4, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZ1J1OTVid0dCY3g0dHk2ZURNd0lPdVBIRGpMQTY5eGtObXZjcGo0WiI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoxMzU4OiJodHRwOi8vZDc1OS0xMzctNTktMjE3LTE0Mi5uZ3Jvay1mcmVlLmFwcC8/ZW1iZWRkZWQ9MSZob3N0PVlXUnRhVzR1YzJodmNHbG1lUzVqYjIwdmMzUnZjbVV2ZEdWemRISnBaR1Z5WlhoemRHOXlaUSZpZF90b2tlbj1leUpoYkdjaU9pSklVekkxTmlJc0luUjVjQ0k2SWtwWFZDSjkuZXlKcGMzTWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dFhDOWhaRzFwYmlJc0ltUmxjM1FpT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRJaXdpWVhWa0lqb2lOak5sTVdJeVpqazBNamMxWXpJeU1tUTBZek13T0RNd05HUTBOVEJtWXpJaUxDSnpkV0lpT2lJNU1UWTNPRFl3TlRNMk9TSXNJbVY0Y0NJNk1UY3pOak0xTnpVM05pd2libUptSWpveE56TTJNelUzTlRFMkxDSnBZWFFpT2pFM016WXpOVGMxTVRZc0ltcDBhU0k2SW1WaVkyTTRNak5pTFRaa09Ua3RORGxqTmkxaU4ySXpMVGMyWW1RMVptVmhPRFE1TkNJc0luTnBaQ0k2SWprMk5qSTFaV1V4TFdRM1lqTXROREF3TlMxaFpEUTRMV00zT1dNMFpqWmhNVGN3WWlJc0luTnBaeUk2SWpWbE5EQmxPVFl4TmpGa05qTXpNVEV3TVdZNE1UTmpPREl4WXpGaU5XVTFZbU16Wm1VeFlXRmtOVE5pTVRsbE16TXpORGRpWWpBMU5HRTBZelV3TURZaWZRLm1XclVROGVHX2t5SzYxQTBabEpVT0FreXZxTzlJM2NnUW5TX0t2dndjWVkmbG9jYWxlPWVuJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFOelU0TWl3aWJtSm1Jam94TnpNMk16VTNOVEl5TENKcFlYUWlPakUzTXpZek5UYzFNaklzSW1wMGFTSTZJamRqTkRka01qUXhMV0ZtWmpFdE5HRm1ZaTA1WWpBMkxUVmpNMlUyTURNMllXRmtPU0lzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJbVZrTlRRd1lUVmtZak16TVdZMk5qWTBZMlUyT0RFNVpETTRaREV4WWpCbE9Ea3pORGRoWkRNek9HSXlaREZtWVRWaE9EbGxOMlUxTldRMk4yVmpORE1pZlEuZkpFdXpjQlcwWVlvb3lTc2hnb2tTdGRJNlFIdTRpczNKdGtfajNjSXBUcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736357587),
('xxYebB8WruRaV10WrWdWhS5Y0eIywGHjvRCbvO3C', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZFNoNnkxYzczTklHUzh0MmE0a0JNdjJmcEcwWXdzckVUcXdPRU9vdSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTQ2MzoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvYXV0aGVudGljYXRlL3Rva2VuP2hvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmxvY2FsZT1lbiZzaG9wPXRlc3RyaWRlcmV4c3RvcmUubXlzaG9waWZ5LmNvbSZ0YXJnZXQ9JTJGJTNGZW1iZWRkZWQlM0QxJTI2aG9zdCUzRFlXUnRhVzR1YzJodmNHbG1lUzVqYjIwdmMzUnZjbVV2ZEdWemRISnBaR1Z5WlhoemRHOXlaUSUyNmlkX3Rva2VuJTNEZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRYQzloWkcxcGJpSXNJbVJsYzNRaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0SWl3aVlYVmtJam9pTmpObE1XSXlaamswTWpjMVl6SXlNbVEwWXpNd09ETXdOR1EwTlRCbVl6SWlMQ0p6ZFdJaU9pSTVNVFkzT0RZd05UTTJPU0lzSW1WNGNDSTZNVGN6TmpNMU9EYzJNaXdpYm1KbUlqb3hOek0yTXpVNE56QXlMQ0pwWVhRaU9qRTNNell6TlRnM01ESXNJbXAwYVNJNkltSTRaakV4WlROaUxXTmxZakF0TkdOak15MWhaVEppTFdZMVltRXdaamcxWmpCbVpTSXNJbk5wWkNJNklqazJOakkxWldVeExXUTNZak10TkRBd05TMWhaRFE0TFdNM09XTTBaalpoTVRjd1lpSXNJbk5wWnlJNklqVm1OVGszTWpjM05ESTBNVGRqWkdJNE0ySmpObVJrTjJaak1XRXdNakpqWlRreE9EQTFPVFpoTjJGaU1EZGpZamMzWTJaa1pUUm1ZMlJpWXpoak0yVWlmUS5TNl8xWnNXMlAwc1RBSzNNTC12UUZNVGcxOFQ3WXVYOG1JdmxDRWVPbFRrJTI2dG9rZW4lM0RleUpoYkdjaU9pSklVekkxTmlJc0luUjVjQ0k2SWtwWFZDSjkuZXlKcGMzTWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dFhDOWhaRzFwYmlJc0ltUmxjM1FpT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRJaXdpWVhWa0lqb2lOak5sTVdJeVpqazBNamMxWXpJeU1tUTBZek13T0RNd05HUTBOVEJtWXpJaUxDSnpkV0lpT2lJNU1UWTNPRFl3TlRNMk9TSXNJbVY0Y0NJNk1UY3pOak0xT0RVNU1Td2libUptSWpveE56TTJNelU0TlRNeExDSnBZWFFpT2pFM016WXpOVGcxTXpFc0ltcDBhU0k2SWpSaU5qWTFaVEptTFdWbFpEQXROREpsT1MwNE1XUmpMV1JqTlRrMVl6SXdZelJtTmlJc0luTnBaQ0k2SWprMk5qSTFaV1V4TFdRM1lqTXROREF3TlMxaFpEUTRMV00zT1dNMFpqWmhNVGN3WWlJc0luTnBaeUk2SWprek1EZzJaV0ZtWm1Ga04ySTBZVGhsTURVNE9UTXlOR05rT0dRM09XTXhaRGhpTVRZeE5XWmpOVFE0WlRnNE5UUTJaVEpqWkdJd1lqVXhNemMwWlRnaWZRLmhZbDlmMTYwTnd1YkQ5NHlsVDNIMDY5YzIxME1pbWk3aWZrLWVraV9FTjAiO319', 1736358734),
('z7J00tAAi5KFmjBDkETBIZ1udKijRteOP50sysuQ', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUmh3dkFqNmNpZU5lV21EaTI2TDZ5WnlxTDdncllQd0MzZ0Q2eklFUCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTQ2MzoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvYXV0aGVudGljYXRlL3Rva2VuP2hvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmxvY2FsZT1lbiZzaG9wPXRlc3RyaWRlcmV4c3RvcmUubXlzaG9waWZ5LmNvbSZ0YXJnZXQ9JTJGJTNGZW1iZWRkZWQlM0QxJTI2aG9zdCUzRFlXUnRhVzR1YzJodmNHbG1lUzVqYjIwdmMzUnZjbVV2ZEdWemRISnBaR1Z5WlhoemRHOXlaUSUyNmlkX3Rva2VuJTNEZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRYQzloWkcxcGJpSXNJbVJsYzNRaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0SWl3aVlYVmtJam9pTmpObE1XSXlaamswTWpjMVl6SXlNbVEwWXpNd09ETXdOR1EwTlRCbVl6SWlMQ0p6ZFdJaU9pSTVNVFkzT0RZd05UTTJPU0lzSW1WNGNDSTZNVGN6TmpNMU56VTNOaXdpYm1KbUlqb3hOek0yTXpVM05URTJMQ0pwWVhRaU9qRTNNell6TlRjMU1UWXNJbXAwYVNJNkltVmlZMk00TWpOaUxUWmtPVGt0TkRsak5pMWlOMkl6TFRjMlltUTFabVZoT0RRNU5DSXNJbk5wWkNJNklqazJOakkxWldVeExXUTNZak10TkRBd05TMWhaRFE0TFdNM09XTTBaalpoTVRjd1lpSXNJbk5wWnlJNklqVmxOREJsT1RZeE5qRmtOak16TVRFd01XWTRNVE5qT0RJeFl6RmlOV1UxWW1NelptVXhZV0ZrTlROaU1UbGxNek16TkRkaVlqQTFOR0UwWXpVd01EWWlmUS5tV3JVUThlR19reUs2MUEwWmxKVU9Ba3l2cU85STNjZ1FuU19LdnZ3Y1lZJTI2dG9rZW4lM0RleUpoYkdjaU9pSklVekkxTmlJc0luUjVjQ0k2SWtwWFZDSjkuZXlKcGMzTWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dFhDOWhaRzFwYmlJc0ltUmxjM1FpT2lKb2RIUndjenBjTDF3dmRHVnpkSEpwWkdWeVpYaHpkRzl5WlM1dGVYTm9iM0JwWm5rdVkyOXRJaXdpWVhWa0lqb2lOak5sTVdJeVpqazBNamMxWXpJeU1tUTBZek13T0RNd05HUTBOVEJtWXpJaUxDSnpkV0lpT2lJNU1UWTNPRFl3TlRNMk9TSXNJbVY0Y0NJNk1UY3pOak0xTnpRek9Td2libUptSWpveE56TTJNelUzTXpjNUxDSnBZWFFpT2pFM016WXpOVGN6Tnprc0ltcDBhU0k2SW1ZelkySTBNalV6TFdRd1lXVXROREppT1MxaU5ETXhMV0kzTmpJMk1UbGpNekJqTkNJc0luTnBaQ0k2SWprMk5qSTFaV1V4TFdRM1lqTXROREF3TlMxaFpEUTRMV00zT1dNMFpqWmhNVGN3WWlJc0luTnBaeUk2SW1GbVpXTXlORFExTkdJNE5tRmtOamswWWpneU5EQTFZbUZpWVRZMk5EUmxaVEkxWWpWaU5EYzNNREpqTmpsaFpXWmtNemhtTW1ZMU5XWmhabUpsWldVaWZRLnpqaVhXOVAwY0JLMkdRajk4MHhQVWdsM2c2V0ZmRVFmQ2N3RkRNMU9KVnciO319', 1736357547),
('Zyprsfw7IdGjmyDWJph0NTsa752kqwVGAABRSknf', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZU5QUURWamc2SERxZktBVmxQYko5TGNFYWdUQ1c0M3V2ZDFMZ2JFWSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTAxNzoiaHR0cDovL2Q3NTktMTM3LTU5LTIxNy0xNDIubmdyb2stZnJlZS5hcHAvYXV0aGVudGljYXRlL3Rva2VuP2VtYmVkZGVkPTEmaG1hYz0xZjczZjg1NjM0ZjA2NDgxZTM3MGM2MWRmZjY5Yzk4NWFkYTlkZWQ5NDUzNjFlZDQzNzMyZWMwYWJlMTdiNDEwJmhvc3Q9WVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJmlkX3Rva2VuPWV5SmhiR2NpT2lKSVV6STFOaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpwYzNNaU9pSm9kSFJ3Y3pwY0wxd3ZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpTNXRlWE5vYjNCcFpua3VZMjl0WEM5aFpHMXBiaUlzSW1SbGMzUWlPaUpvZEhSd2N6cGNMMXd2ZEdWemRISnBaR1Z5WlhoemRHOXlaUzV0ZVhOb2IzQnBabmt1WTI5dElpd2lZWFZrSWpvaU5qTmxNV0l5WmprME1qYzFZekl5TW1RMFl6TXdPRE13TkdRME5UQm1ZeklpTENKemRXSWlPaUk1TVRZM09EWXdOVE0yT1NJc0ltVjRjQ0k2TVRjek5qTTFOelF6TkN3aWJtSm1Jam94TnpNMk16VTNNemMwTENKcFlYUWlPakUzTXpZek5UY3pOelFzSW1wMGFTSTZJamN6Wm1Fd01ESmpMVEl6T0RjdE5EVTJaUzFoT0ROaUxXVXhPVGxoT1ROaU5UTTVOQ0lzSW5OcFpDSTZJamsyTmpJMVpXVXhMV1EzWWpNdE5EQXdOUzFoWkRRNExXTTNPV00wWmpaaE1UY3dZaUlzSW5OcFp5STZJakE1WWpKak56TTRPREl3TW1VMVl6RXpZVGd4WldOak56STFaalUyWlRKak5qRTBaamMzWWpVMU1EVXdOVEV5TmpVek16TTVORGhpWVRVNVpqVTJORE1pZlEuMkRaRThCSWt5LXZEdF9XNzVjNklPckJBdlotT3E3ZjN4UVd3WGtobG5OTSZsb2NhbGU9ZW4mc2Vzc2lvbj04OTk4NGMyMzRiNTMzMjVlZmYyZTBkMjUzYTNlMGU3ZTdlMTMwMWNkYzUxMmNlZTQ1NmUzZmFiZjExYjJiMWZjJnNob3A9dGVzdHJpZGVyZXhzdG9yZS5teXNob3BpZnkuY29tJnRhcmdldD0lMkYlM0Zob3N0JTNEWVdSdGFXNHVjMmh2Y0dsbWVTNWpiMjB2YzNSdmNtVXZkR1Z6ZEhKcFpHVnlaWGh6ZEc5eVpRJnRpbWVzdGFtcD0xNzM2MzU3Mzc0Ijt9fQ==', 1736357402);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shopify_grandfathered` tinyint(1) NOT NULL DEFAULT 0,
  `shopify_namespace` varchar(255) DEFAULT NULL,
  `shopify_freemium` tinyint(1) NOT NULL DEFAULT 0,
  `plan_id` int(10) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `password_updated_at` date DEFAULT NULL,
  `theme_support_level` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `shopify_grandfathered`, `shopify_namespace`, `shopify_freemium`, `plan_id`, `deleted_at`, `password_updated_at`, `theme_support_level`) VALUES
(1, 'riderexapptesting.myshopify.com', 'shop@riderexapptesting.myshopify.com', NULL, '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', NULL, '2025-01-07 11:47:07', '2025-01-07 11:47:34', 0, NULL, 0, NULL, NULL, '2025-01-07', 1),
(2, 'testingriderex.myshopify.com', 'shop@testingriderex.myshopify.com', NULL, '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', NULL, '2025-01-07 12:53:18', '2025-01-07 12:53:39', 0, NULL, 0, NULL, NULL, '2025-01-07', 2),
(3, 'productsfetching.myshopify.com', 'shop@productsfetching.myshopify.com', NULL, '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', NULL, '2025-01-07 13:21:56', '2025-01-07 13:22:07', 0, NULL, 0, NULL, NULL, '2025-01-07', 2),
(4, 'testriderexstore.myshopify.com', 'shop@testriderexstore.myshopify.com', NULL, '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', NULL, '2025-01-07 16:39:12', '2025-01-07 16:39:45', 0, NULL, 0, NULL, NULL, '2025-01-07', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `charges`
--
ALTER TABLE `charges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `charges_user_id_foreign` (`user_id`),
  ADD KEY `charges_plan_id_foreign` (`plan_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_plan_id_foreign` (`plan_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `charges`
--
ALTER TABLE `charges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `charges`
--
ALTER TABLE `charges`
  ADD CONSTRAINT `charges_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`),
  ADD CONSTRAINT `charges_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
